# Load libraries
library(vetiver)
library(plumber)

# Load model
model <- readRDS("linear_model_sold_price.rds")

# Create a Vetiver model object
v <- vetiver_model(model, "sold_price_model")

# Create a plumber API to serve the model
api <- pr() %>%
  vetiver_api(v)

# Run the API on port 8000
api %>% pr_run(port = 8000)

